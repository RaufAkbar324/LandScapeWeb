from flask import Flask, request, jsonify
from flask_cors import CORS
from bs4 import BeautifulSoup
import re
import os
import numpy as np
app = Flask(__name__)
CORS(app)

# === Configurations ===

file_keywords = ['file name', 'alt text']
skip_tags = {'style', 'meta', 'head', 'script', 'title',}
faq_pattern = re.compile(r'frequent(ly)?\s+ask(ed)?\s+questions?', re.IGNORECASE)

# === Utilities ===

def normalize(text):
    return text.replace('\xa0', ' ').replace('\u200b', ' ').strip().lower()

def is_question(tag, text):
    return (
        tag.name.lower() in ['h1', 'h2', 'h3', 'h4', 'h5', 'h6'] or
        text.strip().endswith('?') or
        tag.find(['b', 'strong']) is not None
    )

# === Extractors ===

def extract_head(full_soup):
    """Extracts the first visible child tag inside <body> and returns its text"""
    soup1 = full_soup
    tags = soup1.body.find_all(recursive=False)

    for tag in tags:
        child_tags = tag.find_all(True, recursive=True)  
        for child in child_tags:
            text = child.get_text(strip=True)
            if text:  
                return text  
    return None, ""  


def extract_text_section(full_soup, head_text):
    
    soup2=full_soup
    tags = soup2.body.find_all(recursive=False)

    for tag in tags:
        for child in tag.find_all(recursive=True):  
            if child.string and head_text.strip().lower() == child.string.strip().lower():
                child.decompose()  
                break 

    
   
        

    for tag in tags:
        for child in tag.find_all(True):  
            child_text = child.get_text(strip=True).lower()

            for keyword in file_keywords:
                if keyword in child_text:  
                    child.decompose()  
                    break
                
 
    faq_found = False

    for tag in tags:
        child_tags = tag.find_all(True, recursive=True)

        for child in child_tags:
            direct_text = ''.join(t for t in child.contents if isinstance(t, str)).strip()

            if faq_found:
                if direct_text:  
                    child.decompose()

            elif faq_pattern.search(direct_text):
                faq_found = True  

                
           
    return str(soup2)


# Global FAQ pattern

def extract_faq_section(full_soup):
    soup3 = full_soup
    tags = soup3.find_all(recursive=False)  
      
    direct_text_tags = []

    for tag in tags:
        for descendant in tag.descendants:
            if descendant.name:  
                direct_text = ''.join(child for child in descendant.children if isinstance(child, str)).strip()
                if direct_text:
                    direct_text_tags.append(descendant)
    
      
    for tag in direct_text_tags:
        if hasattr(tag, 'get_text'):
            text = tag.get_text(strip=True)

            if faq_pattern.search(text):
                tag.decompose()  
                
                break
            else:
                tag.decompose()  
                 
    
    faqs = {}
    answers = {}

    faq_index = 1
    ans_index = 1

    for tag in direct_text_tags:
        if tag is None or tag.name is None:
            continue 

        text = tag.get_text(strip=True)
        if not text:
            continue 

        if text.endswith('?'):
            faqs[f"faq-{faq_index}"] = text
            faq_index += 1
        else:
            answers[f"ans-{ans_index}"] = text
            ans_index += 1

    return faqs, answers

    
        
# === API Endpoint ===

@app.route("/parse-html", methods=["GET","POST"])
def parse_html():
    if request.method == "GET":
        return "Welcome to OasisLandscape"
    html = request.json.get("html", "").lstrip('\ufeff')
    soup = BeautifulSoup(html, 'html.parser')

    new_soup1 = BeautifulSoup(str(soup), 'html.parser')
    new_soup2 = BeautifulSoup(str(soup), 'html.parser')
    new_soup3 = BeautifulSoup(str(soup), 'html.parser')
  
    

    head = extract_head(new_soup1)
    text = extract_text_section(new_soup2,head)
    faqs,answers= extract_faq_section(new_soup3)

    result = {
        "head": head,
        "text": text,
        "faq": faqs,
        "ans":answers
    }

    return jsonify(result)

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8000))  # Azure will provide the PORT value
    app.run(host="0.0.0.0", port=port)
